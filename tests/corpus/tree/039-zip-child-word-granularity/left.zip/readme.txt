Install with the setup script.
Run it twice.
