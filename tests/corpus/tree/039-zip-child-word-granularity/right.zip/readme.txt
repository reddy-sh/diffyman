Install with the bootstrap script.
Run it twice.
